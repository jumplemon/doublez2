// 导入必要的模块
const express = require('express');
const fetch = require('node-fetch'); // 用于向DeepL发送请求
require('dotenv').config(); // 读取环境变量

const app = express();
const PORT = process.env.PORT || 3000; // 平台会自动分配端口

// 重要：允许你的网页进行跨域请求
app.use((req, res, next) => {
  // 这里最好替换成你未来网页的精确域名（如 https://yourpage.com），用 '*' 仅用于测试
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Headers', 'Content-Type');
  if (req.method === 'OPTIONS') {
    return res.sendStatus(200);
  }
  next();
});

// 解析前端发送的JSON数据
app.use(express.json());

// 核心：定义翻译接口
app.post('/translate', async (req, res) => {
  try {
    const { text, targetLang = 'EN-US' } = req.body; // 从前端获取要翻译的文本和目标语言

    if (!text) {
      return res.status(400).json({ error: '请提供要翻译的文本' });
    }

    // 从环境变量中读取DeepL密钥（最安全的方式）
    const authKey = process.env.DEEPL_AUTH_KEY;
    if (!authKey) {
      console.error('错误：未设置DEEPL_AUTH_KEY环境变量');
      return res.status(500).json({ error: '服务器配置错误' });
    }

    // 向DeepL API发起请求
    const deepLResponse = await fetch('https://api-free.deepl.com/v2/translate', {
      method: 'POST',
      headers: {
        'Authorization': `DeepL-Auth-Key ${authKey}`,
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      body: new URLSearchParams({
        text: text,
        target_lang: targetLang,
        // source_lang: 'ZH' // 可以指定源语言为中文，也可让DeepL自动检测
      }),
    });

    // 获取DeepL返回的数据
    const data = await deepLResponse.json();

    // 将DeepL的结果原样转发给前端
    res.json(data);

  } catch (error) {
    console.error('翻译请求失败:', error);
    res.status(500).json({ error: '翻译服务暂时不可用' });
  }
});

// 一个简单的健康检查接口，用于测试服务是否在线
app.get('/', (req, res) => {
  res.send('翻译代理服务正在运行。请使用 POST /translate 接口。');
});

// 启动服务器
app.listen(PORT, () => {
  console.log(`✅ 代理服务已启动，监听端口：${PORT}`);
  console.log(`🔧 请确保已设置环境变量：DEEPL_AUTH_KEY`);
});